# thinkphp6 数据库迁移工具

## 安装
~~~
composer require topthink/think-migration
~~~
