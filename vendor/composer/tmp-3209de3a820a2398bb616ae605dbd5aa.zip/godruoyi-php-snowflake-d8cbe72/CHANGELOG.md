# Changelog

All notable changes to godruoyi/php-snowflake are documented in this file using the [Keep a CHANGELOG](http://keepachangelog.com/) principles.

## [1.1.0] - 09.04.2021

### Added

- [#19](https://github.com/godruoyi/php-snowflake/issues/19): Added support for sonyflake Snowflake algorithm. Supported values are:

### Changed

- Add sonyflake support.
- [#19](https://github.com/godruoyi/php-snowflake/issues/19): 能否增加索尼雪花算法。
