<?php
namespace GuzzleHttp\Command\Exception;

/**
 * Exception encountered when a 4xx level response is received for a request
 */
class CommandClientException extends CommandException {}
