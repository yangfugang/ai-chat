
## Installation
```
composer require alibabacloud/tea --optimize-autoloader
```
> Some users may not be able to install due to network problems, you can try to switch the Composer mirror.


## Changelog
Detailed changes for each release are documented in the [release notes](CHANGELOG.md).


## License
[Apache-2.0](LICENSE.md)

Copyright (c) 2009-present, Alibaba Cloud All rights reserved.
