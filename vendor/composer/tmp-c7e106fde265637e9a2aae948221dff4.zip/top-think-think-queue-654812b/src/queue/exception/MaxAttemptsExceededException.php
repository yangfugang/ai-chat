<?php

namespace think\queue\exception;

use RuntimeException;

class MaxAttemptsExceededException extends RuntimeException
{

}
