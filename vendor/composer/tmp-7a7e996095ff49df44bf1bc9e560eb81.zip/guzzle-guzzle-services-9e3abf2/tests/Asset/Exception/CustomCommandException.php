<?php
namespace GuzzleHttp\Tests\Command\Guzzle\Asset\Exception;

use GuzzleHttp\Command\Exception\CommandException;

/**
 * Class CustomCommandException
 *
 * @package GuzzleHttp\Tests\Command\Guzzle\Asset\Exception
 */
class CustomCommandException extends CommandException
{
}
