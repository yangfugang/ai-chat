<?php
namespace GuzzleHttp\Tests\Command\Guzzle\Asset\Exception;

use GuzzleHttp\Command\Exception\CommandException;

/**
 * Class OtherCustomCommandException
 *
 * @package GuzzleHttp\Tests\Command\Guzzle\Asset\Exception
 */
class OtherCustomCommandException extends CommandException
{
}
