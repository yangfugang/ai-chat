<?php
header("Content-Type: application/json;charset=UTF-8");
echo '{"msg": "ok"}';
