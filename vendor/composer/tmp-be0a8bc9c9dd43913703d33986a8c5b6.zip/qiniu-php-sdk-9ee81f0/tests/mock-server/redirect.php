<?php
header("Content-Type: text/plain;charset=UTF-8", true);
header("Location: ./ok.php", true, 301);
echo "redirect to ok.php";
exit();
