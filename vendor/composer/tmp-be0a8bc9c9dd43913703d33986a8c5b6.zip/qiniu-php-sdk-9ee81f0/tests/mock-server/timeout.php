<?php
sleep(10);
echo "OK";
