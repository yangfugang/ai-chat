<?php

namespace Songshenzong\Support;

use Songshenzong\Support\Traits\Str;
use Songshenzong\Support\Traits\Uri;

/**
 * Class Strings
 *
 * @package Songshenzong\Support
 */
class Strings
{
    use Str, Uri;
}
