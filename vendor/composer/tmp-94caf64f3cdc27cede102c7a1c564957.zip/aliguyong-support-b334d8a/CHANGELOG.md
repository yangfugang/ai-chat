# ChangeLog

---

## 2.0.5 - 2019-08-30
- Improved `Time`.

## 2.0.4 - 2019-08-30
- Added `Time`.

## 2.0.3 - 2019-08-27
- Added `Env` for `OS`.

## 2.0.2 - 2019-08-14
- Added `get` for `Arrays`.

## 2.0.1 - 2019-06-12
- Added `Arrays`.

## 2.0.0 - 2019-06-12
- Improved Design.

## 1.0.0 - 2017-03-07
- Released
